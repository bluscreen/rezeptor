CREATE DATABASE  IF NOT EXISTS `rezeptor` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `rezeptor`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: rezeptor
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `ID` bigint(20) NOT NULL,
  `BERECHTIGUNG` int(11) DEFAULT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `GEBURTSDATUM` date DEFAULT NULL,
  `LASTLOGINDATE` datetime DEFAULT NULL,
  `NACHNAME` varchar(255) DEFAULT NULL,
  `NOTIZEN` longtext,
  `PASSWORT` varchar(255) NOT NULL,
  `THUMBURL` varchar(255) DEFAULT NULL,
  `VORNAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EMAIL` (`EMAIL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,100,'testuser@dhbw.de',NULL,'2014-03-30 15:37:00','Hammacher',NULL,'$2a$12$q6ZfcAmfk.i9PdAh1kMUt.43CX5bOjP4SwZ2LfpTOX2b45fsVcVoq',NULL,'Daniel'),(157,1,'borth@dhbw.de','1111-11-11','2014-03-30 15:36:41','Borth',NULL,'$2a$12$0mwJJbS2SeM1.SDNeooFpOkz/68klV9gU6mBiI.O0W6Pp4PveMNPS',NULL,'Beate'),(158,0,'ebner@dhbw.de','1111-11-11','2014-03-30 15:02:56','Ebner',NULL,'$2a$12$nAMCK/7Jo02nPYzN3brvBuiL5Uyw.5Y1hC2C52xeG1kDsD8o.bsF2',NULL,'Axel'),(159,0,'reinhardt@dhbw.de','1111-11-11','2014-03-30 15:14:17','Reinhardt',NULL,'$2a$12$xVMpEiQ5Ohj8PRetpzQIPeva/aq0fC2iLRhnZ.O1zMi9STX0lc.by',NULL,'Nadine'),(160,0,'orth@dhbw.de','1111-11-11','2014-03-30 15:19:06','Orth',NULL,'$2a$12$.DSk0j.RYi9qBkNDd2pklOBvejASvSn6eRbYRwWp2dKiQz4lakrzq',NULL,'Fabian ');
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-03-30 15:40:24
